import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { notifyOwner } from "./_core/notification";
import {
  getOrCreateVisitorProfile, recordPageVisit, addXP,
  getChatHistory, saveChatMessage, saveContactSubmission,
  getCodexEntries, seedCodexEntries, updateVisitorProfile,
  saveResearchSession, getResearchSessions,
  createFlashcardDeck, addFlashcardsToDecks, getFlashcardDecks,
  getFlashcardsForDeck, getDueFlashcards, reviewFlashcard,
  rateLessonAndFeedback, getLessonRating, getLessonStats,
  startLessonProgress, completeLessonProgress, getLessonProgress, getUserProgress, getStudyStats,
  startCurriculumProgress, updateCurriculumProgress, getCurriculumProgress,
  getAIProviderSettings, upsertAIProviderSettings,
  getMindMaps, getMindMapById, saveMindMap, updateMindMap, deleteMindMap,
  getLibraryResources, getDb,
  saveLesson, getLessonById, getLessonsByCurriculum, markLessonComplete,
  askLessonQuestion, saveLessonAnswer, getLessonQuestions, getQuestionAnswer,
  markAnswerHelpful, incrementLessonViewCount, searchSharedLessons, markLessonAsShared,
} from "./db";
import { invokeAI, testProviderConnection, DEFAULT_MODELS, type AIProvider } from "./aiProvider";
import { libraryResources, testResults, iqResults, type MindMapNode, type InsertLesson, type InsertLessonQuestion } from "../drizzle/schema";
import { eq, desc, isNotNull, sql } from "drizzle-orm";

// ─── Unified AI helper — respects user's stored provider preference ────────────
async function getProviderConfig(cookieId?: string) {
  if (cookieId) {
    const s = await getAIProviderSettings(cookieId);
    if (s) return { provider: s.provider as AIProvider, apiKey: s.apiKey ?? null, model: s.model ?? null };
  }
  return { provider: "builtin" as AIProvider, apiKey: null, model: null };
}

async function callAI(
  cookieId: string | undefined,
  prompt: string,
  systemPrompt?: string,
  maxTokens = 1024
): Promise<string> {
  const config = await getProviderConfig(cookieId);
  return invokeAI(config, {
    messages: [
      ...(systemPrompt ? [{ role: "system" as const, content: systemPrompt }] : []),
      { role: "user" as const, content: prompt },
    ],
    maxTokens,
  });
}

async function callAIChat(
  cookieId: string | undefined,
  messages: Array<{ role: "user" | "assistant"; content: string }>,
  systemPrompt: string
): Promise<string> {
  const config = await getProviderConfig(cookieId);
  return invokeAI(config, {
    messages: [
      { role: "system" as const, content: systemPrompt },
      ...messages,
    ],
    maxTokens: 1024,
  });
}

const NEXUS_SYSTEM_PROMPT = `You are the AI assistant for Nexus — an AI-powered learning and research platform built by Tim Schmoyer (Fredericksburg, VA). You are knowledgeable, articulate, and intellectually engaging.

About Nexus:
- An AI-powered learning and research platform designed to fill real gaps in EdTech
- Features: Adaptive Curriculum Generator, Research Forge (document analysis + flashcards), Depth Engine (5-level concept explainer), Lab (coding challenges), Library (knowledge base), Mind Maps, Flashcard Review
- Built with React, TypeScript, tRPC, and multi-provider AI (Gemini, Perplexity, OpenAI)
- Philosophy: Learning should be adaptive, Socratic, and deeply personalized

About Tim Schmoyer:
- Software engineer and AI systems builder based in Fredericksburg, Virginia
- Specializes in AI-augmented web applications and learning systems
- Creator of Nexus

Your role:
- Help users understand and navigate the platform
- Answer questions about learning, research, and the platform's features
- Be intellectually engaging and encourage exploration
- Suggest relevant platform features based on what the user is asking about
- Keep responses concise but substantive`;

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ─── Visitor / Personalization ──────────────────────────────────────────────
  visitor: router({
    getProfile: publicProcedure
      .input(z.object({ cookieId: z.string() }))
      .query(async ({ input }) => {
        return getOrCreateVisitorProfile(input.cookieId);
      }),

    recordVisit: publicProcedure
      .input(z.object({ cookieId: z.string(), page: z.string() }))
      .mutation(async ({ input }) => {
        return recordPageVisit(input.cookieId, input.page);
      }),

    addXP: publicProcedure
      .input(z.object({ cookieId: z.string(), amount: z.number().positive() }))
      .mutation(async ({ input }) => {
        return addXP(input.cookieId, input.amount);
      }),

    updateInterests: publicProcedure
      .input(z.object({ cookieId: z.string(), interests: z.array(z.string()) }))
      .mutation(async ({ input }) => {
        await updateVisitorProfile(input.cookieId, { interests: input.interests });
        return { success: true };
      }),

    completeQuiz: publicProcedure
      .input(z.object({
        cookieId: z.string(),
        results: z.record(z.string(), z.string()),
        preferredTopics: z.array(z.string()),
      }))
      .mutation(async ({ input }) => {
        await updateVisitorProfile(input.cookieId, {
          quizCompleted: true,
          quizResults: input.results,
          preferredTopics: input.preferredTopics,
        });
        const xpResult = await addXP(input.cookieId, 50);
        return { success: true, ...xpResult };
      }),
  }),

  // ─── AI — all procedures route through the unified provider switcher ─────────
  ai: router({
    generateGreeting: publicProcedure
      .input(z.object({
        cookieId: z.string(),
        visitCount: z.number(),
        pagesVisited: z.array(z.string()),
        preferredTopics: z.array(z.string()),
        timeOfDay: z.string(),
        xp: z.number(),
      }))
      .mutation(async ({ input }) => {
        const isReturning = input.visitCount > 1;
        const prompt = isReturning
          ? `Generate a short (2-3 sentences), sophisticated, personalized welcome-back message for a returning visitor to Nexus — an AI-powered learning platform.
             Visit count: ${input.visitCount}. Pages they've explored: ${input.pagesVisited.join(", ")}.
             Their interests: ${input.preferredTopics.join(", ") || "not yet determined"}.
             Their XP level: ${input.xp}. Time of day: ${input.timeOfDay}.
             Be warm but intellectually engaging. Reference their learning journey. No generic phrases.`
          : `Generate a short (2-3 sentences), sophisticated, compelling first-time greeting for a new visitor to Nexus — an AI-powered learning and research platform.
             Time of day: ${input.timeOfDay}.
             Make it feel like entering a place built for serious, curious minds. Intriguing, not cheesy. Professional yet evocative.`;
        const greeting = await callAI(input.cookieId, prompt);
        return { greeting };
      }),

    generateQuiz: publicProcedure
      .input(z.object({ cookieId: z.string() }))
      .mutation(async ({ input }) => {
        const prompt = `Generate 4 adaptive quiz questions to help personalize a learning platform experience.
        The questions should reveal the visitor's background, interests, and goals.
        Return ONLY valid JSON in this exact format:
        {
          "questions": [
            {
              "id": "q1",
              "question": "...",
              "options": ["A: ...", "B: ...", "C: ...", "D: ..."],
              "category": "background|interests|goals|style"
            }
          ]
        }
        Make questions intellectually engaging, not generic. Topics: technical background, creative interests, learning goals, work style.
        Each question should have exactly 4 options labeled A, B, C, D.`;
        const response = await callAI(input.cookieId, prompt);
        try {
          const jsonMatch = response.match(/\{[\s\S]*\}/);
          if (jsonMatch) {
            const parsed = JSON.parse(jsonMatch[0]) as { questions: Array<{ id: string; question: string; options: string[]; category: string }> };
            return { questions: parsed.questions };
          }
        } catch (_e) { /* fallback */ }
        return {
          questions: [
            { id: "q1", question: "What best describes your relationship with technology?", options: ["A: I build it — software engineer or developer", "B: I design it — UX/product designer", "C: I strategize it — product or business", "D: I'm curious about it — learning and exploring"], category: "background" },
            { id: "q2", question: "What draws you to Nexus most?", options: ["A: Building a personalized learning path", "B: Researching and analyzing documents with AI", "C: Interactive coding challenges and experiments", "D: The curated knowledge library"], category: "interests" },
            { id: "q3", question: "What's your primary learning goal right now?", options: ["A: Master a specific technical skill", "B: Understand a complex topic deeply", "C: Stay current with AI and technology trends", "D: Explore broadly — I'm not sure yet"], category: "goals" },
            { id: "q4", question: "How do you prefer to learn?", options: ["A: Deep dives — give me the technical details", "B: Visual — show me, don't tell me", "C: Socratic — ask me questions, guide me to discover", "D: Interactive — let me build and experiment"], category: "style" },
          ],
        };
      }),

    explainConcept: publicProcedure
      .input(z.object({
        cookieId: z.string().optional(),
        concept: z.string().max(500),
        level: z.enum(["child", "student", "expert", "socratic", "analogy"]),
      }))
      .mutation(async ({ input }) => {
        const levelPrompts: Record<string, string> = {
          child: `Explain "${input.concept}" to a curious 8-year-old. Use simple words, concrete examples, and maybe a fun analogy. No jargon whatsoever. Make it feel like a story or adventure.`,
          student: `Explain "${input.concept}" to a high school or early college student. Introduce proper terminology with clear definitions. Use 2-3 concrete examples. Build from fundamentals. Be thorough but accessible.`,
          expert: `Explain "${input.concept}" at a graduate/expert level. Assume strong domain knowledge. Use precise technical language. Cover edge cases, nuances, and connections to adjacent concepts. Be rigorous.`,
          socratic: `Use the Socratic method to guide someone to understand "${input.concept}". Ask 5-7 probing questions that progressively lead them to discover the concept themselves. Don't explain — only ask. Each question should build on the previous.`,
          analogy: `Explain "${input.concept}" using 3 vivid analogies from completely different domains (e.g., cooking, architecture, sports, music, nature). Each analogy should illuminate a different aspect of the concept. Make them memorable and precise.`,
        };
        const explanation = await callAI(input.cookieId, levelPrompts[input.level], undefined, 1500);
        return { explanation, level: input.level };
      }),

    generateCurriculum: publicProcedure
      .input(z.object({
        cookieId: z.string().optional(),
        goal: z.string().max(500),
        currentLevel: z.enum(["beginner", "intermediate", "advanced"]),
        timeAvailable: z.string(),
        interests: z.array(z.string()),
      }))
      .mutation(async ({ input }) => {
        const prompt = `Create a personalized learning curriculum for someone with this goal: "${input.goal}"
        Current level: ${input.currentLevel}
        Time available: ${input.timeAvailable}
        Related interests: ${input.interests.join(", ") || "general"}

        Return ONLY valid JSON in this exact format:
        {
          "title": "...",
          "description": "...",
          "estimatedWeeks": 4,
          "phases": [
            {
              "phase": 1,
              "title": "...",
              "duration": "Week 1-2",
              "objectives": ["...", "..."],
              "resources": [
                { "title": "...", "type": "article|video|book|practice", "url": "...", "description": "..." }
              ],
              "milestone": "..."
            }
          ]
        }
        Create 3-4 phases. Be specific with real resources (actual URLs when possible). Make it genuinely actionable.`;
        const response = await callAI(input.cookieId, prompt, undefined, 2048);
        let curriculum: any = null;
        try {
          const jsonMatch = response.match(/\{[\s\S]*\}/);
          if (jsonMatch) {
            curriculum = JSON.parse(jsonMatch[0]);
          }
        } catch (_e) { /* fallback */ }
        if (!curriculum) {
          curriculum = { title: `Learning Path: ${input.goal}`, description: "A personalized curriculum.", estimatedWeeks: 4, phases: [{ phase: 1, title: "Foundation", duration: "Week 1", objectives: ["Understand core concepts"], resources: [{ title: "Getting Started", type: "article", url: "#", description: "Introduction" }], milestone: "Complete first project" }] };
        }
        
        // Auto-generate lessons for each phase
        const curriculumId = `curriculum-${Date.now()}`;
        const cookieId = input.cookieId || "anonymous";
        for (let i = 0; i < curriculum.phases.length; i++) {
          const phase = curriculum.phases[i];
          try {
            const lessonPrompt = `Create a comprehensive lesson for: "${phase.title}"\nObjectives: ${phase.objectives.join(", ")}\nDuration: ${phase.duration}\n\nProvide detailed, practical content in markdown format with examples and explanations.`;
            const lessonContent = await callAI(cookieId, lessonPrompt, undefined, 3000);
            
            await saveLesson({
              cookieId,
              curriculumId,
              title: phase.title,
              description: phase.objectives.join(", "),
              content: lessonContent,
              objectives: phase.objectives,
              keyPoints: phase.objectives,
              resources: phase.resources,
              externalResources: [],
              order: i,
              difficulty: input.currentLevel,
              estimatedMinutes: 30,
              isShared: true,
              relatedTopics: input.interests,
            });
          } catch (err) {
            console.error(`Failed to generate lesson for phase ${i}:`, err);
          }
        }
        
        return { ...curriculum, curriculumId };
      }),

    generateLesson: publicProcedure
      .input(z.object({
        cookieId: z.string(),
        curriculumId: z.string(),
        title: z.string(),
        objectives: z.array(z.string()),
        duration: z.string(),
        order: z.number(),
      }))
      .mutation(async ({ input }) => {
        const prompt = `Create a comprehensive, engaging lesson on: "${input.title}"
        Objectives: ${input.objectives.join(", ")}
        Duration: ${input.duration}

        Return ONLY valid JSON with lesson content in markdown format.
        Make it detailed, practical, and engaging with examples.`;
        const response = await callAI(input.cookieId, prompt, undefined, 3000);
        const lesson: InsertLesson = {
          cookieId: input.cookieId,
          curriculumId: input.curriculumId,
          title: input.title,
          description: input.objectives.join(", "),
          content: response,
          objectives: input.objectives,
          keyPoints: input.objectives,
          resources: [],
          order: input.order,
          difficulty: "intermediate",
          estimatedMinutes: 15,
        };
        const saved = await saveLesson(lesson);
        return saved || { id: 0, ...lesson, completed: false, completedAt: null, createdAt: new Date(), updatedAt: new Date() };
      }),

    getLesson: publicProcedure
      .input(z.object({ lessonId: z.number() }))
      .query(async ({ input }) => {
        return getLessonById(input.lessonId);
      }),

    getLessonsByCurriculum: publicProcedure
      .input(z.object({ cookieId: z.string(), curriculumId: z.string() }))
      .query(async ({ input }) => {
        return getLessonsByCurriculum(input.cookieId, input.curriculumId);
      }),

    completeLesson: publicProcedure
      .input(z.object({ lessonId: z.number(), cookieId: z.string() }))
      .mutation(async ({ input }) => {
        await markLessonComplete(input.lessonId);
        await addXP(input.cookieId, 25);
        return { success: true };
      }),

    askLessonQuestion: publicProcedure
      .input(z.object({ lessonId: z.number(), cookieId: z.string(), question: z.string().max(1000) }))
      .mutation(async ({ input }) => {
        const q = await askLessonQuestion(input.lessonId, input.cookieId, input.question);
        if (!q) return { error: "Failed to save question" };
        const lesson = await getLessonById(input.lessonId);
        if (!lesson) return { error: "Lesson not found" };
        const prompt = `You are helping a student with the lesson: "${lesson.title}"\n\nLesson content:\n${lesson.content}\n\nStudent question: ${input.question}\n\nProvide a clear, concise answer based on the lesson content.`;
        const answer = await callAI(input.cookieId, prompt, undefined, 1024);
        const saved = await saveLessonAnswer(q.id, answer);
        return { question: q, answer: saved };
      }),

    getLessonQA: publicProcedure
      .input(z.object({ lessonId: z.number() }))
      .query(async ({ input }) => {
        const questions = await getLessonQuestions(input.lessonId);
        const qas = await Promise.all(
          questions.map(async (q) => ({
            question: q,
            answer: await getQuestionAnswer(q.id),
          }))
        );
        return qas;
      }),

    markAnswerHelpful: publicProcedure
      .input(z.object({ answerId: z.number() }))
      .mutation(async ({ input }) => {
        await markAnswerHelpful(input.answerId);
        return { success: true };
      }),

    exploreOffTopic: publicProcedure
      .input(z.object({ cookieId: z.string(), currentTopic: z.string(), relatedTopic: z.string() }))
      .mutation(async ({ input }) => {
        const prompt = `Create a comprehensive lesson on: "${input.relatedTopic}" which is related to "${input.currentTopic}".`;
        const response = await callAI(input.cookieId, prompt, undefined, 3000);
        const lesson: InsertLesson = {
          cookieId: input.cookieId,
          curriculumId: `exploration-${Date.now()}`,
          title: input.relatedTopic,
          description: `Related exploration from: ${input.currentTopic}`,
          content: response,
          objectives: [`Understand ${input.relatedTopic}`],
          keyPoints: [],
          resources: [],
          order: 0,
          difficulty: "intermediate",
          estimatedMinutes: 20,
          isShared: true,
          relatedTopics: [input.currentTopic],
        };
        const saved = await saveLesson(lesson);
        return saved;
      }),

    searchSharedLessons: publicProcedure
      .input(z.object({ query: z.string().max(200) }))
      .query(async ({ input }) => {
        return searchSharedLessons(input.query);
      }),

    startSocraticSession: publicProcedure
      .input(z.object({ cookieId: z.string().optional(), topic: z.string().max(500), userLevel: z.string() }))
      .mutation(async ({ input }) => {
        const prompt = `You are a Socratic tutor. The student wants to learn about: "${input.topic}". Their level: ${input.userLevel}.
        Start a Socratic dialogue with ONE opening question that will reveal what they already know and begin guiding them toward understanding.
        The question should be thought-provoking but not overwhelming. Don't explain anything — only ask.`;
        const question = await callAI(input.cookieId, prompt, undefined, 256);
        return { question, sessionId: Date.now().toString() };
      }),

    continueSocraticSession: publicProcedure
      .input(z.object({
        cookieId: z.string().optional(),
        topic: z.string().max(500),
        history: z.array(z.object({ role: z.enum(["tutor", "student"]), content: z.string() })),
        userResponse: z.string().max(2000),
      }))
      .mutation(async ({ input }) => {
        const historyText = input.history.map((h) => `${h.role === "tutor" ? "Tutor" : "Student"}: ${h.content}`).join("\n");
        const prompt = `You are a Socratic tutor teaching about: "${input.topic}".
        Conversation so far:\n${historyText}\nStudent: ${input.userResponse}\n
        Respond as a Socratic tutor: acknowledge what's correct, gently redirect misconceptions with a question (never directly correct), and ask the next probing question. Keep it conversational. 2-3 sentences max.`;
        const response = await callAI(input.cookieId, prompt, undefined, 512);
        return { response };
      }),

    chat: publicProcedure
      .input(z.object({
        cookieId: z.string(),
        message: z.string().max(2000),
        profile: z.object({
          visitCount: z.number(),
          pagesVisited: z.array(z.string()),
          preferredTopics: z.array(z.string()),
          xp: z.number(),
          level: z.number(),
        }).optional(),
      }))
      .mutation(async ({ input }) => {
        const history = await getChatHistory(input.cookieId, 10);
        const chatMessages: Array<{ role: "user" | "assistant"; content: string }> = history.map(msg => ({
          role: msg.role === "user" ? "user" as const : "assistant" as const,
          content: msg.content,
        }));
        const contextNote = input.profile
          ? `\n\n[Visitor context: Visit #${input.profile.visitCount}, explored: ${input.profile.pagesVisited.join(", ")}, XP: ${input.profile.xp}, Level: ${input.profile.level}, interests: ${input.profile.preferredTopics.join(", ")}]`
          : "";
        chatMessages.push({ role: "user", content: input.message + contextNote });
        const response = await callAIChat(input.cookieId, chatMessages, NEXUS_SYSTEM_PROMPT);
        await saveChatMessage(input.cookieId, "user", input.message);
        await saveChatMessage(input.cookieId, "assistant", response);
        const xpResult = await addXP(input.cookieId, 15);
        return { response, ...xpResult };
      }),

    explainCodex: publicProcedure
      .input(z.object({
        cookieId: z.string().optional(),
        title: z.string(),
        description: z.string(),
        category: z.string(),
      }))
      .mutation(async ({ input }) => {
        const prompt = `Provide a concise, insightful 2-3 sentence explanation of why "${input.title}" is important and what makes it valuable for someone interested in ${input.category}. Be specific and intellectually engaging. No fluff.`;
        const explanation = await callAI(input.cookieId, prompt);
        return { explanation };
      }),

    composeMessage: publicProcedure
      .input(z.object({
        cookieId: z.string().optional(),
        intent: z.string(),
        context: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const prompt = `Help compose a professional message for someone reaching out to the creator of Nexus, an AI learning platform.
        Their intent: "${input.intent}".
        Additional context: "${input.context || "none"}".
        Write a polished, concise message (3-4 sentences) they could send. Make it genuine and specific.`;
        const draft = await callAI(input.cookieId, prompt);
        return { draft };
      }),

    searchLibrary: publicProcedure
      .input(z.object({
        cookieId: z.string().optional(),
        query: z.string().max(500),
      }))
      .mutation(async ({ input }) => {
        const resources = await getLibraryResources(undefined, input.query);
        if (resources.length === 0) return { results: [], aiSummary: null };
        const resourceList = resources.slice(0, 5).map(r => `- ${r.title}: ${r.description}`).join("\n");
        const prompt = `A user searched for "${input.query}" in a learning library. Here are the most relevant resources found:\n${resourceList}\n\nWrite a 2-3 sentence synthesis explaining how these resources relate to the query and what the user will learn from them. Be specific and helpful.`;
        const aiSummary = await callAI(input.cookieId, prompt);
        return { results: resources, aiSummary };
      }),
  }),

  // ─── Research ──────────────────────────────────────────────────────────────
  research: router({
    analyze: publicProcedure
      .input(z.object({
        cookieId: z.string().optional(),
        content: z.string().max(50000),
        mode: z.enum(["text", "url"]),
      }))
      .mutation(async ({ input }) => {
        let textToAnalyze = input.content;
        if (input.mode === "url") {
          try {
            const res = await fetch(input.content, { headers: { "User-Agent": "Mozilla/5.0 (compatible; NexusBot/1.0)" } });
            const html = await res.text();
            textToAnalyze = html.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").slice(0, 15000);
          } catch (_e) {
            textToAnalyze = `Content from URL: ${input.content}. Could not fetch the page directly. Please paste the text content instead.`;
          }
        }
        const prompt = `Analyze the following content and extract structured knowledge. Return ONLY valid JSON in this exact format:
        {
          "title": "A concise, descriptive title for this content",
          "summary": "A comprehensive markdown-formatted summary (3-5 paragraphs). Include the main thesis, key arguments, and conclusions. Use headers and bullet points where appropriate.",
          "keyInsights": ["Specific, actionable insight 1", "Specific, actionable insight 2", "Specific, actionable insight 3", "Specific, actionable insight 4", "Specific, actionable insight 5"],
          "flashcards": [
            { "front": "Question or concept", "back": "Clear, concise answer or explanation" },
            { "front": "Question or concept", "back": "Clear, concise answer or explanation" },
            { "front": "Question or concept", "back": "Clear, concise answer or explanation" },
            { "front": "Question or concept", "back": "Clear, concise answer or explanation" },
            { "front": "Question or concept", "back": "Clear, concise answer or explanation" }
          ],
          "tags": ["tag1", "tag2", "tag3", "tag4"]
        }
        Content to analyze:\n${textToAnalyze.slice(0, 12000)}\n
        Make the flashcards genuinely useful for spaced repetition learning. Key insights should be specific and actionable.`;
        const response = await callAI(input.cookieId, prompt, undefined, 3000);
        try {
          const jsonMatch = response.match(/\{[\s\S]*\}/);
          if (jsonMatch) {
            return JSON.parse(jsonMatch[0]) as { title: string; summary: string; keyInsights: string[]; flashcards: Array<{ front: string; back: string }>; tags: string[] };
          }
        } catch (_e) { /* fallback */ }
        return { title: "Analysis Complete", summary: response, keyInsights: ["See full summary for key points"], flashcards: [], tags: [] };
      }),

    save: publicProcedure
      .input(z.object({
        cookieId: z.string(),
        title: z.string(),
        sourceText: z.string().optional(),
        sourceUrl: z.string().optional(),
        summary: z.string().optional(),
        keyInsights: z.array(z.string()).optional(),
        notes: z.string().optional(),
        tags: z.array(z.string()).optional(),
      }))
      .mutation(async ({ input }) => {
        const id = await saveResearchSession(input);
        await addXP(input.cookieId, 10);
        return { id, success: true };
      }),

    getSessions: publicProcedure
      .input(z.object({ cookieId: z.string() }))
      .query(async ({ input }) => {
        return getResearchSessions(input.cookieId);
      }),

    generateCitation: publicProcedure
      .input(z.object({
        cookieId: z.string().optional(),
        title: z.string(),
        url: z.string().optional(),
        author: z.string().optional(),
        year: z.string().optional(),
        publisher: z.string().optional(),
        format: z.enum(["apa", "mla", "chicago", "harvard"]),
      }))
      .mutation(async ({ input }) => {
        const prompt = `Generate a ${input.format.toUpperCase()} citation for the following source. Return ONLY valid JSON with this exact format:
{
  "citation": "The complete formatted citation string",
  "inText": "The in-text citation format (e.g., (Author, Year) for APA)",
  "notes": "Any important notes about the citation format"
}

Source details:
Title: ${input.title}
URL: ${input.url ?? "N/A"}
Author: ${input.author ?? "Unknown"}
Year: ${input.year ?? new Date().getFullYear().toString()}
Publisher: ${input.publisher ?? "N/A"}
Format: ${input.format.toUpperCase()}`;
        const response = await callAI(input.cookieId, prompt, undefined, 500);
        try {
          const jsonMatch = response.match(/\{[\s\S]*\}/);
          if (jsonMatch) return JSON.parse(jsonMatch[0]) as { citation: string; inText: string; notes: string };
        } catch (_e) { /* fallback */ }
        return { citation: response, inText: "", notes: "" };
      }),

    compareTopics: publicProcedure
      .input(z.object({
        cookieId: z.string().optional(),
        topicA: z.string().min(2).max(500),
        topicB: z.string().min(2).max(500),
        context: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const prompt = `Compare and contrast "${input.topicA}" vs "${input.topicB}"${input.context ? ` in the context of: ${input.context}` : ""}. Return ONLY valid JSON:
{
  "title": "Comparison title",
  "overview": "2-3 sentence overview of both topics",
  "similarities": ["Similarity 1", "Similarity 2", "Similarity 3"],
  "differences": [
    { "aspect": "Aspect name", "topicA": "How topic A relates", "topicB": "How topic B relates" },
    { "aspect": "Aspect name", "topicA": "How topic A relates", "topicB": "How topic B relates" },
    { "aspect": "Aspect name", "topicA": "How topic A relates", "topicB": "How topic B relates" },
    { "aspect": "Aspect name", "topicA": "How topic A relates", "topicB": "How topic B relates" }
  ],
  "verdict": "When to use/prefer each one — a balanced conclusion",
  "useCases": { "topicA": ["Use case 1", "Use case 2"], "topicB": ["Use case 1", "Use case 2"] }
}`;
        const response = await callAI(input.cookieId, prompt, undefined, 2000);
        try {
          const jsonMatch = response.match(/\{[\s\S]*\}/);
          if (jsonMatch) return JSON.parse(jsonMatch[0]) as { title: string; overview: string; similarities: string[]; differences: Array<{ aspect: string; topicA: string; topicB: string }>; verdict: string; useCases: { topicA: string[]; topicB: string[] } };
        } catch (_e) { /* fallback */ }
        return { title: "Comparison", overview: response, similarities: [], differences: [], verdict: "", useCases: { topicA: [], topicB: [] } };
      }),
  }),

  // ─── Contact ────────────────────────────────────────────────────────────────
  contact: router({
    submit: publicProcedure
      .input(z.object({
        cookieId: z.string().optional(),
        name: z.string().min(1).max(256),
        email: z.string().email(),
        subject: z.string().max(512).optional(),
        message: z.string().min(10).max(5000),
      }))
      .mutation(async ({ input }) => {
        await saveContactSubmission(input);
        await notifyOwner({
          title: `New Contact: ${input.name}`,
          content: `From: ${input.name} <${input.email}>\nSubject: ${input.subject ?? "No subject"}\n\n${input.message}`,
        });
        if (input.cookieId) {
          await addXP(input.cookieId, 25);
        }
        return { success: true };
      }),
  }),

  // ─── Codex ──────────────────────────────────────────────────────────────────
  codex: router({
    list: publicProcedure
      .input(z.object({ category: z.string().optional() }))
      .query(async ({ input }) => {
        await seedCodexEntries();
        const entries = await getCodexEntries(input.category);
        return entries;
      }),
  }),

  // ─── Flashcards ─────────────────────────────────────────────────────────────
  flashcards: router({
    getDecks: publicProcedure
      .input(z.object({ cookieId: z.string() }))
      .query(async ({ input }) => getFlashcardDecks(input.cookieId)),
    getCards: publicProcedure
      .input(z.object({ deckId: z.number() }))
      .query(async ({ input }) => getFlashcardsForDeck(input.deckId)),
    getDueCards: publicProcedure
      .input(z.object({ deckId: z.number() }))
      .query(async ({ input }) => getDueFlashcards(input.deckId)),
    createDeckFromResearch: publicProcedure
      .input(z.object({
        cookieId: z.string(),
        title: z.string(),
        description: z.string().optional(),
        cards: z.array(z.object({ front: z.string(), back: z.string() })),
        sourceId: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const deckId = await createFlashcardDeck({
          cookieId: input.cookieId,
          title: input.title,
          description: input.description,
          sourceType: input.sourceId ? "research" : "ai_generated",
          sourceId: input.sourceId,
        });
        await addFlashcardsToDecks(deckId, input.cards);
        await addXP(input.cookieId, 20);
        return { deckId, success: true };
      }),
    generateDeck: publicProcedure
      .input(z.object({
        cookieId: z.string(),
        topic: z.string(),
        count: z.number().min(5).max(30).default(10),
      }))
      .mutation(async ({ input }) => {
        const prompt = `Generate ${input.count} high-quality spaced repetition flashcards for: "${input.topic}".
Return ONLY valid JSON: {"cards":[{"front":"question","back":"answer"}]}`;
        const response = await callAI(input.cookieId, prompt, undefined, 2000);
        let cards: Array<{ front: string; back: string }> = [];
        try {
          const m = response.match(/\{[\s\S]*\}/);
          if (m) cards = (JSON.parse(m[0]) as { cards: Array<{ front: string; back: string }> }).cards;
        } catch (_e) { /* fallback */ }
        const deckId = await createFlashcardDeck({ cookieId: input.cookieId, title: `${input.topic} — Flashcards`, sourceType: "ai_generated" });
        await addFlashcardsToDecks(deckId, cards);
        await addXP(input.cookieId, 15);
        return { deckId, cardCount: cards.length, success: true };
      }),
    review: publicProcedure
      .input(z.object({
        cardId: z.number(),
        deckId: z.number(),
        cookieId: z.string(),
        rating: z.enum(["again", "hard", "good", "easy"]),
      }))
      .mutation(async ({ input }) => {
        await reviewFlashcard(input.cardId, input.deckId, input.cookieId, input.rating);
        if (input.rating === "good" || input.rating === "easy") await addXP(input.cookieId, 2);
        return { success: true };
      }),
    completeSession: publicProcedure
      .input(z.object({ cookieId: z.string(), cardsReviewed: z.number() }))
      .mutation(async ({ input }) => addXP(input.cookieId, Math.min(input.cardsReviewed * 3, 50))),
  }),

  // ─── AI Provider ───────────────────────────────────────────────────────────────
  aiProvider: router({
    get: publicProcedure
      .input(z.object({ cookieId: z.string() }))
      .query(async ({ input }) => {
        const s = await getAIProviderSettings(input.cookieId);
        return { provider: s?.provider ?? "gemini", model: s?.model ?? null, hasCustomKey: !!(s?.apiKey), defaultModels: DEFAULT_MODELS };
      }),
    set: publicProcedure
      .input(z.object({ cookieId: z.string(), provider: z.enum(["gemini","perplexity","openai"]), apiKey: z.string().optional(), model: z.string().optional() }))
      .mutation(async ({ input }) => {
        await upsertAIProviderSettings(input.cookieId, { provider: input.provider, apiKey: input.apiKey, model: input.model });
        return { success: true };
      }),
    test: publicProcedure
      .input(z.object({ provider: z.enum(["gemini","perplexity","openai"]), apiKey: z.string().optional(), model: z.string().optional() }))
      .mutation(async ({ input }) => testProviderConnection({ provider: input.provider as AIProvider, apiKey: input.apiKey ?? null, model: input.model ?? null })),
    clearKey: publicProcedure
      .input(z.object({ cookieId: z.string() }))
      .mutation(async ({ input }) => {
        const s = await getAIProviderSettings(input.cookieId);
        if (s) await upsertAIProviderSettings(input.cookieId, { provider: s.provider, apiKey: undefined, model: s.model ?? undefined });
        return { success: true };
      }),
  }),

  // ─── Mind Maps ───────────────────────────────────────────────────────────────
  mindmap: router({
    list: publicProcedure
      .input(z.object({ cookieId: z.string() }))
      .query(async ({ input }) => getMindMaps(input.cookieId)),
    get: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => getMindMapById(input.id)),
    generate: publicProcedure
      .input(z.object({ cookieId: z.string(), topic: z.string(), depth: z.number().min(1).max(3).default(2) }))
      .mutation(async ({ input }) => {
        const prompt = `Generate a comprehensive mind map for "${input.topic}" at depth ${input.depth}.
Return ONLY valid JSON:
{"nodes":[{"id":"root","label":"${input.topic}","parentId":null,"category":"root","x":0,"y":0},{"id":"n1","label":"Main concept","parentId":"root","category":"primary","x":250,"y":-150}]}
Rules: root node id is always "root". Generate 6-10 primary nodes. For depth 2+, add 2-3 children per primary. Spread nodes radially (x/y range -600 to 600). Labels: 2-5 words. Categories: root, primary, secondary, tertiary.`;
        const response = await callAI(input.cookieId, prompt, undefined, 3000);
        let nodes: MindMapNode[] = [];
        try {
          const m = response.match(/\{[\s\S]*\}/);
          if (m) nodes = (JSON.parse(m[0]) as { nodes: MindMapNode[] }).nodes;
        } catch (_e) { /* fallback */ }
        const mapId = await saveMindMap({ cookieId: input.cookieId, title: input.topic, rootTopic: input.topic, nodesJson: nodes });
        await addXP(input.cookieId, 15);
        return { mapId, nodes, success: true };
      }),
    expandNode: publicProcedure
      .input(z.object({
        cookieId: z.string(), mapId: z.number(), nodeId: z.string(), nodeLabel: z.string(),
        existingNodes: z.array(z.object({ id: z.string(), label: z.string(), parentId: z.string().nullable(), category: z.string().optional(), x: z.number(), y: z.number() })),
      }))
      .mutation(async ({ input }) => {
        const prompt = `Expand "${input.nodeLabel}" in a mind map. Existing: ${input.existingNodes.map(n => n.label).join(", ")}.
Generate 4-6 new child nodes. Return ONLY valid JSON: {"nodes":[{"id":"exp_1","label":"concept","parentId":"${input.nodeId}","category":"secondary","x":0,"y":0}]}`;
        const response = await callAI(input.cookieId, prompt, undefined, 1000);
        let newNodes: MindMapNode[] = [];
        try {
          const m = response.match(/\{[\s\S]*\}/);
          if (m) {
            const ts = Date.now();
            newNodes = (JSON.parse(m[0]) as { nodes: MindMapNode[] }).nodes.map((n, i) => ({ ...n, id: `exp_${ts}_${i}` }));
          }
        } catch (_e) { /* fallback */ }
        const allNodes = [...input.existingNodes, ...newNodes] as MindMapNode[];
        await updateMindMap(input.mapId, { nodesJson: allNodes });
        await addXP(input.cookieId, 5);
        return { newNodes, success: true };
      }),
    save: publicProcedure
      .input(z.object({ cookieId: z.string(), title: z.string(), rootTopic: z.string(), nodesJson: z.array(z.any()) }))
      .mutation(async ({ input }) => {
        const mapId = await saveMindMap({ cookieId: input.cookieId, title: input.title, rootTopic: input.rootTopic, nodesJson: input.nodesJson as MindMapNode[] });
        return { mapId, success: true };
      }),
    update: publicProcedure
      .input(z.object({ id: z.number(), title: z.string().optional(), nodesJson: z.array(z.any()).optional() }))
      .mutation(async ({ input }) => { await updateMindMap(input.id, { title: input.title, nodesJson: input.nodesJson as MindMapNode[] | undefined }); return { success: true }; }),
    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => { await deleteMindMap(input.id); return { success: true }; }),
  }),

  // ─── Lab AI Procedures ─────────────────────────────────────────────────────────────────
  lab: router({
    promptExperiment: publicProcedure
      .input(z.object({ cookieId: z.string(), task: z.string(), technique: z.enum(["zero-shot","few-shot","chain-of-thought","role"]) }))
      .mutation(async ({ input }) => {
        const prompts: Record<string, string> = {
          "zero-shot": input.task,
          "few-shot": `Here are examples of clear explanations:\nExample 1: Explain gravity \u2192 Gravity is the force that pulls objects toward each other.\nExample 2: Explain photosynthesis \u2192 Photosynthesis is how plants convert sunlight into food.\nNow, using the same clear style:\n${input.task}`,
          "chain-of-thought": `Let's think through this step by step.\n\n${input.task}\n\nReason carefully, showing each step of your thinking before the final answer.`,
          "role": `You are a world-class educator known for making complex topics accessible. You have 30 years of experience at MIT and have written 12 bestselling books on science communication.\n\nWith that expertise, address:\n${input.task}`,
        };
        const response = await callAI(input.cookieId, prompts[input.technique], `You are demonstrating the "${input.technique}" prompting technique. Be thorough and educational.`);
        return { response, technique: input.technique };
      }),
    chainOfThought: publicProcedure
      .input(z.object({ cookieId: z.string(), problem: z.string() }))
      .mutation(async ({ input }) => {
        const prompt = `Break down this problem into numbered reasoning steps. Each step = one logical move. End with a final answer.\nProblem: ${input.problem}\nReturn ONLY a JSON array of strings: ["Step 1: ...","Step 2: ...","Final Answer: ..."]`;
        const response = await callAI(input.cookieId, prompt, "You are a logical reasoning expert. Always return valid JSON arrays.", 1200);
        let steps: string[] = [];
        try {
          const m = response.match(/\[[\s\S]*\]/);
          if (m) steps = JSON.parse(m[0]) as string[];
        } catch (_e) {
          steps = response.split("\n").filter((l: string) => l.trim().length > 0).slice(0, 8);
        }
        if (steps.length === 0) steps = [response];
        return { steps };
      }),
    classifyText: publicProcedure
      .input(z.object({ cookieId: z.string(), text: z.string() }))
      .mutation(async ({ input }) => {
        const prompt = `Classify this text. Return ONLY valid JSON:\n{"sentiment":"positive|negative|neutral|mixed","topic":"<2-3 words>","intent":"<2-3 words>","tone":"<1-2 words>","confidence":<integer 60-98>}\n\nText: ${input.text.slice(0,2000)}`;
        const response = await callAI(input.cookieId, prompt, "You are an NLP classification expert. Always return valid JSON.", 300);
        try {
          const m = response.match(/\{[\s\S]*\}/);
          if (m) return JSON.parse(m[0]) as { sentiment: string; topic: string; intent: string; tone: string; confidence: number };
        } catch (_e) { /* fallback */ }
        return { sentiment: "neutral", topic: "General", intent: "Informational", tone: "Neutral", confidence: 75 };
      }),
    debate: publicProcedure
      .input(z.object({ cookieId: z.string(), topic: z.string() }))
      .mutation(async ({ input }) => {
        const [proRes, conRes] = await Promise.all([
          callAI(input.cookieId, `You are a passionate advocate FOR: "${input.topic}". Make the strongest argument in 3-4 paragraphs.`, "You argue FOR the position. Be persuasive.", 600),
          callAI(input.cookieId, `You are a passionate advocate AGAINST: "${input.topic}". Make the strongest counter-argument in 3-4 paragraphs.`, "You argue AGAINST the position. Be persuasive.", 600),
        ]);
        return { pro: proRes, con: conRes };
      }),
    debugCode: publicProcedure
      .input(z.object({ cookieId: z.string(), code: z.string(), error: z.string() }))
      .mutation(async ({ input }) => {
        const prompt = `A student has JavaScript code that produced an error. Explain what went wrong and how to fix it.\n\nCode:\n\`\`\`javascript\n${input.code.slice(0,3000)}\n\`\`\`\n\nError: ${input.error.slice(0,500)}\n\nProvide: 1) What caused the error, 2) The fix, 3) A brief explanation of the concept.`;
        const explanation = await callAI(input.cookieId, prompt, "You are a patient coding tutor. Be clear and educational.", 600);
        return { explanation };
      }),
    describeImage: publicProcedure
      .input(z.object({ cookieId: z.string(), imageUrl: z.string().url() }))
      .mutation(async ({ input }) => {
        const { invokeLLM } = await import("./_core/llm");
        const response = await invokeLLM({
          messages: [
            { role: "system", content: "You are an expert image analyst. Describe images in rich, structured detail covering: main subjects, composition, colors, mood, text visible, technical quality, and any interesting observations. Be thorough but organized." },
            { role: "user", content: [{ type: "image_url", image_url: { url: input.imageUrl, detail: "high" } }, { type: "text", text: "Describe this image in detail. Cover: 1) Main subjects and objects, 2) Composition and layout, 3) Colors and lighting, 4) Mood and atmosphere, 5) Any text or symbols, 6) Technical observations, 7) Interesting details." }] },
          ],
        });
        const description = (response as { choices: Array<{ message: { content: string } }> }).choices?.[0]?.message?.content ?? "Unable to analyze image.";
        return { description };
      }),
    tokenCount: publicProcedure
      .input(z.object({ cookieId: z.string(), text: z.string(), model: z.enum(["gpt-4o", "gpt-3.5-turbo", "claude-3-opus", "gemini-1.5-pro", "llama-3-70b"]) }))
      .mutation(async ({ input }) => {
        // Approximate token counting using GPT-4 tokenization heuristic (~4 chars per token)
        const charCount = input.text.length;
        const wordCount = input.text.split(/\s+/).filter(Boolean).length;
        const approxTokens = Math.round(charCount / 4);
        // Model pricing per 1M tokens (input/output in USD)
        const pricing: Record<string, { input: number; output: number; contextWindow: number }> = {
          "gpt-4o": { input: 2.50, output: 10.00, contextWindow: 128000 },
          "gpt-3.5-turbo": { input: 0.50, output: 1.50, contextWindow: 16385 },
          "claude-3-opus": { input: 15.00, output: 75.00, contextWindow: 200000 },
          "gemini-1.5-pro": { input: 1.25, output: 5.00, contextWindow: 1000000 },
          "llama-3-70b": { input: 0.59, output: 0.79, contextWindow: 8192 },
        };
        const modelInfo = pricing[input.model];
        const inputCost = (approxTokens / 1_000_000) * modelInfo.input;
        const outputCost = (approxTokens / 1_000_000) * modelInfo.output;
        const contextUsed = Math.round((approxTokens / modelInfo.contextWindow) * 100);
        return {
          tokens: approxTokens,
          characters: charCount,
          words: wordCount,
          model: input.model,
          inputCostUSD: parseFloat(inputCost.toFixed(6)),
          outputCostUSD: parseFloat(outputCost.toFixed(6)),
          contextWindowTokens: modelInfo.contextWindow,
          contextUsedPercent: Math.min(100, contextUsed),
          fitsInContext: approxTokens <= modelInfo.contextWindow,
        };
      }),
    socraticTutor: publicProcedure
      .input(z.object({ cookieId: z.string(), topic: z.string(), userAnswer: z.string().optional(), questionNumber: z.number().default(1) }))
      .mutation(async ({ input }) => {
        const isFirst = !input.userAnswer;
        const prompt = isFirst
          ? `You are a Socratic tutor. The student wants to learn about: "${input.topic}". Ask them the FIRST probing question to start discovering what they already know. The question should be open-ended and thought-provoking. Do NOT explain the topic — only ask. Keep the question to 1-2 sentences.`
          : `You are a Socratic tutor teaching about "${input.topic}". This is question ${input.questionNumber} of 6. The student answered: "${input.userAnswer}". Acknowledge their answer briefly (1 sentence), then ask the NEXT probing question that builds on their response and moves them closer to understanding the core concept. Never give the answer directly.`;
        const question = await callAI(input.cookieId, prompt, "You are a Socratic tutor. Never explain — only ask questions that guide discovery.", 300);
        const isComplete = input.questionNumber >= 6;
        let insight = "";
        if (isComplete) {
          insight = await callAI(input.cookieId, `The student has been exploring "${input.topic}" through Socratic questioning. Their last answer was: "${input.userAnswer}". Now provide a concise synthesis (3-4 sentences) that connects the dots and reveals the core insight they've been discovering. Make it feel like an 'aha moment'.`, "You are a Socratic tutor delivering the final insight.", 400);
        }
        return { question, isComplete, insight };
      }),
    storyGen: publicProcedure
      .input(z.object({ cookieId: z.string(), genre: z.string(), premise: z.string(), choice: z.string().optional(), storyHistory: z.string().optional() }))
      .mutation(async ({ input }) => {
        const isFirst = !input.choice;
        const prompt = isFirst
          ? `You are a collaborative storyteller. Genre: ${input.genre}. Premise: "${input.premise}". Write the opening scene (3-4 paragraphs, vivid and engaging). End with EXACTLY 3 choices for the reader, formatted as:\nCHOICE_A: [action]\nCHOICE_B: [action]\nCHOICE_C: [action]`
          : `You are a collaborative storyteller. Genre: ${input.genre}. Story so far:\n${input.storyHistory}\n\nThe reader chose: "${input.choice}". Continue the story (3-4 paragraphs) based on this choice. Then end with EXACTLY 3 new choices:\nCHOICE_A: [action]\nCHOICE_B: [action]\nCHOICE_C: [action]`;
        const response = await callAI(input.cookieId, prompt, "You are a master storyteller. Write vivid, engaging prose with clear narrative choices.", 800);
        const choiceMatches = response.match(/CHOICE_[ABC]: (.+)/g) ?? [];
        const choices = choiceMatches.map((c: string) => c.replace(/CHOICE_[ABC]: /, "").trim());
        const storyText = response.replace(/CHOICE_[ABC]: .+/g, "").trim();
        return { story: storyText, choices: choices.length === 3 ? choices : ["Continue the adventure", "Take a different path", "Seek help from an ally"] };
      }),
    biasDetect: publicProcedure
      .input(z.object({ cookieId: z.string(), text: z.string() }))
      .mutation(async ({ input }) => {
        const prompt = `Analyze this text for cognitive biases, logical fallacies, and rhetorical manipulation. Return ONLY valid JSON:\n{"biases":[{"name":"<bias name>","quote":"<exact quote from text, max 60 chars>","explanation":"<why this is a bias>","severity":"low|medium|high"}],"overallScore":<0-100 objectivity score>,"summary":"<2-3 sentence overall assessment>"}\n\nText to analyze:\n${input.text.slice(0, 3000)}`;
        const response = await callAI(input.cookieId, prompt, "You are a critical thinking expert specializing in cognitive biases and logical fallacies. Always return valid JSON.", 800);
        try {
          const m = response.match(/\{[\s\S]*\}/);
          if (m) return JSON.parse(m[0]) as { biases: Array<{ name: string; quote: string; explanation: string; severity: string }>; overallScore: number; summary: string };
        } catch (_e) { /* fallback */ }
        return { biases: [], overallScore: 75, summary: "Unable to analyze text for biases. Please try again." };
      }),
  }),

  // ─── Library ─────────────────────────────────────────────────────────────────
  library: router({
    list: publicProcedure
      .input(z.object({ category: z.string().optional(), search: z.string().optional() }))
      .query(async ({ input }) => getLibraryResources(input.category, input.search)),
    contribute: publicProcedure
      .input(z.object({
        cookieId: z.string(),
        title: z.string().min(3).max(200),
        url: z.string().url(),
        description: z.string().min(10).max(1000),
        category: z.string(),
        tags: z.array(z.string()).max(8),
        type: z.enum(["article", "video", "course", "tool", "paper", "book", "repo"]),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });
        const existing = await db.select().from(libraryResources).where(eq(libraryResources.url, input.url)).limit(1);
        if (existing.length > 0) {
          throw new TRPCError({ code: "CONFLICT", message: "This resource is already in the Library." });
        }
        await db.insert(libraryResources).values({
          title: input.title,
          url: input.url,
          description: input.description,
          category: input.category,
          tags: input.tags,
          type: input.type,
          featured: false,
          contributedBy: input.cookieId,
        });
        const xpResult = await addXP(input.cookieId, 50);
        return { success: true, message: "Resource added to the Library! +50 XP", ...xpResult };
      }),
    rateResource: publicProcedure
      .input(z.object({
        resourceId: z.number().int().positive(),
        rating: z.number().int().min(1).max(5),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });
        await db.update(libraryResources)
          .set({
            ratingSum: sql`ratingSum + ${input.rating}`,
            ratingCount: sql`ratingCount + 1`,
          })
          .where(eq(libraryResources.id, input.resourceId));
        return { success: true };
      }),
    trackView: publicProcedure
      .input(z.object({ resourceId: z.number().int().positive() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) return { success: false };
        await db.update(libraryResources)
          .set({ viewCount: sql`viewCount + 1` })
          .where(eq(libraryResources.id, input.resourceId));
        return { success: true };
      }),
    listCommunity: publicProcedure
      .input(z.object({ limit: z.number().int().min(1).max(50).default(20), offset: z.number().int().min(0).default(0) }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return { items: [] as typeof libraryResources.$inferSelect[], total: 0 };
        const items = await db.select().from(libraryResources)
          .where(isNotNull(libraryResources.contributedBy))
          .orderBy(desc(libraryResources.addedAt))
          .limit(input.limit).offset(input.offset);
        const countResult = await db.select({ count: sql<number>`count(*)` }).from(libraryResources)
          .where(isNotNull(libraryResources.contributedBy));
        const total = Number(countResult[0]?.count ?? 0);
        return { items, total };
      }),
  }),

  // ─── Testing Center ──────────────────────────────────────────────────────────
  testing: router({
    saveResult: publicProcedure
      .input(z.object({
        cookieId: z.string().min(1),
        testId: z.string().min(1),
        score: z.number(),
        totalQuestions: z.number(),
        answers: z.record(z.string(), z.number()),
        timeTakenSeconds: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });
        await db.insert(testResults).values({
          cookieId: input.cookieId,
          testId: input.testId,
          score: input.score,
          totalQuestions: input.totalQuestions,
          answers: input.answers,
          timeTakenSeconds: input.timeTakenSeconds ?? null,
        });
        const pct = input.score / input.totalQuestions;
        const xp = pct >= 0.9 ? 100 : pct >= 0.7 ? 60 : pct >= 0.5 ? 30 : 15;
        const xpResult = await addXP(input.cookieId, xp);
        return { success: true, xpAwarded: xp, ...xpResult };
      }),
    saveIQResult: publicProcedure
      .input(z.object({
        cookieId: z.string().min(1),
        iqScore: z.number().min(40).max(200),
        percentile: z.number(),
        rawScore: z.number(),
        categoryScores: z.record(z.string(), z.number()),
        timeTakenSeconds: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });
        await db.insert(iqResults).values({
          cookieId: input.cookieId,
          iqScore: input.iqScore,
          percentile: input.percentile,
          rawScore: input.rawScore,
          categoryScores: input.categoryScores,
          timeTakenSeconds: input.timeTakenSeconds ?? null,
        });
        const xpResult = await addXP(input.cookieId, 75);
        return { success: true, xpAwarded: 75, ...xpResult };
      }),
    getResults: publicProcedure
      .input(z.object({ cookieId: z.string() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return { testResults: [], iqResults: [] };
        const [tests, iqs] = await Promise.all([
          db.select().from(testResults).where(eq(testResults.cookieId, input.cookieId)).orderBy(desc(testResults.completedAt)).limit(50),
          db.select().from(iqResults).where(eq(iqResults.cookieId, input.cookieId)).orderBy(desc(iqResults.completedAt)).limit(10),
        ]);
        return { testResults: tests, iqResults: iqs };
      }),
    getScoreHistory: publicProcedure
      .input(z.object({ cookieId: z.string() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return { subjects: {} as Record<string, Array<{ attempt: number; score: number; totalQuestions: number; pct: number; completedAt: Date; timeTakenSeconds: number | null }>>, iqHistory: [] as Array<{ attempt: number; iqScore: number; percentile: number; rawScore: number; categoryScores: Record<string, number>; completedAt: Date; timeTakenSeconds: number | null }> };
        const [tests, iqs] = await Promise.all([
          db.select({
            id: testResults.id,
            testId: testResults.testId,
            score: testResults.score,
            totalQuestions: testResults.totalQuestions,
            timeTakenSeconds: testResults.timeTakenSeconds,
            completedAt: testResults.completedAt,
          })
            .from(testResults)
            .where(eq(testResults.cookieId, input.cookieId))
            .orderBy(testResults.completedAt),
          db.select({
            id: iqResults.id,
            iqScore: iqResults.iqScore,
            percentile: iqResults.percentile,
            rawScore: iqResults.rawScore,
            categoryScores: iqResults.categoryScores,
            timeTakenSeconds: iqResults.timeTakenSeconds,
            completedAt: iqResults.completedAt,
          })
            .from(iqResults)
            .where(eq(iqResults.cookieId, input.cookieId))
            .orderBy(iqResults.completedAt),
        ]);
        // Group test results by subject (testId), ordered oldest→newest for charting
        const subjects: Record<string, Array<{ attempt: number; score: number; totalQuestions: number; pct: number; completedAt: Date; timeTakenSeconds: number | null }>> = {};
        for (const t of tests) {
          if (!subjects[t.testId]) subjects[t.testId] = [];
          const attempt = subjects[t.testId].length + 1;
          subjects[t.testId].push({
            attempt,
            score: t.score,
            totalQuestions: t.totalQuestions,
            pct: Math.round((t.score / t.totalQuestions) * 100),
            completedAt: t.completedAt,
            timeTakenSeconds: t.timeTakenSeconds ?? null,
          });
        }
        const iqHistory = iqs.map((r, i) => ({
          attempt: i + 1,
          iqScore: r.iqScore,
          percentile: r.percentile,
          rawScore: r.rawScore,
          categoryScores: r.categoryScores as Record<string, number>,
          completedAt: r.completedAt,
          timeTakenSeconds: r.timeTakenSeconds ?? null,
        }));
        return { subjects, iqHistory };
      }),
    generateAdaptiveQuestions: publicProcedure
      .input(z.object({
        cookieId: z.string(),
        subject: z.string(),
        difficulty: z.enum(["beginner", "intermediate", "advanced"]),
        count: z.number().min(3).max(15).default(10),
      }))
      .mutation(async ({ input }) => {
        const prompt = `Generate ${input.count} multiple-choice questions for a knowledge assessment on: "${input.subject}" at ${input.difficulty} difficulty.\n\nReturn ONLY a JSON array:\n[{"id":"q1","question":"...","options":["A) ...","B) ...","C) ...","D) ..."],"correct":0,"explanation":"..."}]\n\nMake questions genuinely educational and progressively challenging.`;
        const raw = await callAI(input.cookieId, prompt, "You are an expert educator. Return only valid JSON.", 2000);
        try {
          const jsonMatch = raw.match(/\[[\s\S]*\]/);
          if (!jsonMatch) throw new Error("No JSON array");
          const questions = JSON.parse(jsonMatch[0]) as any[];
          return { questions };
        } catch {
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to generate questions. Please try again." });
        }
      }),
  }),

  // ─── Leaderboard ────────────────────────────────────────────
  dashboard: router({
    getActivity: publicProcedure
      .input(z.object({ cookieId: z.string().min(1) }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return { days: [], totalActions: 0, avgPerDay: 0 };
        const { researchSessions, testResults: tr, iqResults: iq, flashcardReviews, flashcardDecks } = await import("../drizzle/schema");
        const [research, tests, iqs, reviews] = await Promise.all([
          db.select({ createdAt: researchSessions.createdAt }).from(researchSessions).where(eq(researchSessions.cookieId, input.cookieId)),
          db.select({ createdAt: tr.completedAt }).from(tr).where(eq(tr.cookieId, input.cookieId)),
          db.select({ createdAt: iq.completedAt }).from(iq).where(eq(iq.cookieId, input.cookieId)),
          db.select({ createdAt: flashcardReviews.reviewedAt }).from(flashcardReviews)
            .innerJoin(flashcardDecks, eq(flashcardReviews.deckId, flashcardDecks.id))
            .where(eq(flashcardDecks.cookieId, input.cookieId)),
        ]);
        const dayMap: Record<string, number> = {};
        const allDates = [
          ...research.map(r => r.createdAt),
          ...tests.map(r => r.createdAt),
          ...iqs.map(r => r.createdAt),
          ...reviews.map(r => r.createdAt),
        ].filter(Boolean);
        for (const d of allDates) {
          const key = new Date(d as Date).toISOString().slice(0, 10);
          dayMap[key] = (dayMap[key] ?? 0) + 1;
        }
        const days: Array<{ date: string; count: number }> = [];
        for (let i = 83; i >= 0; i--) {
          const d = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10);
          days.push({ date: d, count: dayMap[d] ?? 0 });
        }
        const totalActions = allDates.length;
        const avgPerDay = totalActions > 0 ? Math.round((totalActions / 84) * 10) / 10 : 0;
        return { days, totalActions, avgPerDay };
      }),
    getInsight: publicProcedure
      .input(z.object({ cookieId: z.string().min(1) }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return { insight: null };
        const { testResults: tr, iqResults: iq } = await import("../drizzle/schema");
        const [tests, iqs] = await Promise.all([
          db.select().from(tr).where(eq(tr.cookieId, input.cookieId)).orderBy(desc(tr.completedAt)).limit(20),
          db.select().from(iq).where(eq(iq.cookieId, input.cookieId)).orderBy(desc(iq.completedAt)).limit(1),
        ]);
        if (tests.length === 0 && iqs.length === 0) return { insight: null };
        const subjectScores: Record<string, number[]> = {};
        for (const t of tests) {
          const pct = Math.round((t.score / t.totalQuestions) * 100);
          if (!subjectScores[t.testId]) subjectScores[t.testId] = [];
          subjectScores[t.testId].push(pct);
        }
        const subjectAvgs = Object.entries(subjectScores).map(([id, scores]) => ({
          id, avg: Math.round(scores.reduce((a, b) => a + b, 0) / scores.length)
        })).sort((a, b) => b.avg - a.avg);
        const strongest = subjectAvgs[0];
        const weakest = subjectAvgs[subjectAvgs.length - 1];
        const latestIQ = iqs[0];
        const subjectNames: Record<string, string> = {
          ai: "AI Knowledge", science: "Science", history: "World History",
          math: "Mathematics", logic: "Logic & Reasoning", language: "Language",
          geography: "Geography", philosophy: "Philosophy", technology: "Technology",
          "art-history": "Art & Culture",
        };
        let insightText = "";
        if (strongest && weakest && strongest.id !== weakest.id) {
          insightText = `You're strongest in **${subjectNames[strongest.id] ?? strongest.id}** (avg ${strongest.avg}%) and have the most room to grow in **${subjectNames[weakest.id] ?? weakest.id}** (avg ${weakest.avg}%). `;
        } else if (strongest) {
          insightText = `You're performing well in **${subjectNames[strongest.id] ?? strongest.id}** with an average of ${strongest.avg}%. `;
        }
        if (latestIQ) {
          const tier = latestIQ.iqScore >= 130 ? "exceptional" : latestIQ.iqScore >= 115 ? "above average" : latestIQ.iqScore >= 100 ? "average" : "developing";
          insightText += `Your IQ assessment of **${latestIQ.iqScore}** places you in the ${tier} range (${latestIQ.percentile}th percentile). `;
        }
        if (tests.length >= 3) {
          const recentScores = tests.slice(0, 3).map(t => Math.round((t.score / t.totalQuestions) * 100));
          const trend = recentScores[0] > recentScores[2] ? "improving" : recentScores[0] < recentScores[2] ? "declining" : "stable";
          insightText += `Your recent performance trend is **${trend}**.`;
        }
        return { insight: insightText || null };
      }),
  }),

  leaderboard: router({
    getTopUsers: publicProcedure
      .input(z.object({ limit: z.number().min(1).max(50).default(20), metric: z.enum(["xp", "streak", "visitCount"]).default("xp") }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return { users: [] };
        const { visitorProfiles } = await import("../drizzle/schema");
        const { desc: descOrder } = await import("drizzle-orm");
        const col = input.metric === "xp" ? visitorProfiles.xp : input.metric === "streak" ? visitorProfiles.streak : visitorProfiles.visitCount;
        const rows = await db.select({
          cookieId: visitorProfiles.cookieId,
          xp: visitorProfiles.xp,
          level: visitorProfiles.level,
          streak: visitorProfiles.streak,
          visitCount: visitorProfiles.visitCount,
          badges: visitorProfiles.badges,
          preferredTopics: visitorProfiles.preferredTopics,
          createdAt: visitorProfiles.createdAt,
        }).from(visitorProfiles).orderBy(descOrder(col)).limit(input.limit);
        return { users: rows.map((r, i) => ({ ...r, rank: i + 1, displayName: `Explorer #${r.cookieId.slice(-6).toUpperCase()}` })) };
      }),
    getMyRank: publicProcedure
      .input(z.object({ cookieId: z.string(), metric: z.enum(["xp", "streak", "visitCount"]).default("xp") }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return { rank: null, total: 0 };
        const { visitorProfiles } = await import("../drizzle/schema");
        const { desc: descOrder, sql: sqlExpr } = await import("drizzle-orm");
        const col = input.metric === "xp" ? visitorProfiles.xp : input.metric === "streak" ? visitorProfiles.streak : visitorProfiles.visitCount;
        const me = await db.select({ val: col }).from(visitorProfiles).where(eq(visitorProfiles.cookieId, input.cookieId)).limit(1);
        if (!me.length) return { rank: null, total: 0 };
        const myVal = me[0].val ?? 0;
        const above = await db.select({ count: sqlExpr<number>`count(*)` }).from(visitorProfiles).where(sql`${col} > ${myVal}`);
        const total = await db.select({ count: sqlExpr<number>`count(*)` }).from(visitorProfiles);
        return { rank: (above[0]?.count ?? 0) + 1, total: total[0]?.count ?? 0, value: myVal };
      }),
  }),

  daily: router({
    getChallenge: publicProcedure
      .input(z.object({ cookieId: z.string() }))
      .query(async ({ input }) => {
        // Deterministic daily seed based on date
        const today = new Date();
        const seed = today.getFullYear() * 10000 + (today.getMonth() + 1) * 100 + today.getDate();
        const categories = ["AI Theory", "Prompt Engineering", "Machine Learning", "AI Ethics", "Practical AI", "Neural Networks", "NLP", "Computer Vision"];
        const categoryIdx = seed % categories.length;
        const category = categories[categoryIdx];

        const prompt = `Generate a daily AI learning challenge for the category "${category}".
Return a JSON object with exactly these fields:
{
  "title": "short challenge title (max 8 words)",
  "category": "${category}",
  "description": "2-3 sentence description of what to do",
  "difficulty": "beginner" | "intermediate" | "advanced",
  "estimatedMinutes": number between 5 and 30,
  "tasks": ["task 1", "task 2", "task 3"],
  "tip": "one actionable pro tip",
  "xpReward": number between 25 and 100
}
Make it practical, specific, and achievable in the estimated time. Seed: ${seed}`;

        const { invokeLLM } = await import("./_core/llm");
        const response = await invokeLLM({
          messages: [
            { role: "system", content: "You are a learning challenge designer. Always respond with valid JSON only." },
            { role: "user", content: prompt },
          ],
          response_format: { type: "json_object" },
        });

        const rawContent = response.choices[0]?.message?.content ?? "{}";
        const content = typeof rawContent === "string" ? rawContent : JSON.stringify(rawContent);
        const data = JSON.parse(content);
        return {
          title: data.title ?? "Daily AI Challenge",
          category: data.category ?? category,
          description: data.description ?? "Explore today's AI concept.",
          difficulty: data.difficulty ?? "intermediate",
          estimatedMinutes: data.estimatedMinutes ?? 15,
          tasks: Array.isArray(data.tasks) ? data.tasks : [],
          tip: data.tip ?? "",
          xpReward: data.xpReward ?? 50,
          date: today.toISOString().split("T")[0],
          seed,
        };
      }),

    complete: publicProcedure
      .input(z.object({ cookieId: z.string().min(1), challengeDate: z.string() }))
      .mutation(async ({ input }) => {
        // Award XP for completing daily challenge
        const db = await getDb();
        if (!db) return { success: false, xpGained: 0, newXp: 0, newLevel: 1 };
        const { visitorProfiles } = await import("../drizzle/schema");
        const existing = await db.select().from(visitorProfiles).where(eq(visitorProfiles.cookieId, input.cookieId)).limit(1);
        if (existing.length > 0) {
          const current = existing[0];
          const xpGain = 75;
          const newXp = (current.xp ?? 0) + xpGain;
          const newLevel = Math.floor(1 + Math.sqrt(newXp / 100));
          await db.update(visitorProfiles)
            .set({ xp: newXp, level: newLevel } as Record<string, unknown>)
            .where(eq(visitorProfiles.cookieId, input.cookieId));
          return { success: true, xpGained: xpGain, newXp, newLevel };
        }
        return { success: false, xpGained: 0, newXp: 0, newLevel: 1 };
      }),

    getOrCreateLesson: publicProcedure
      .input(z.object({ cookieId: z.string(), title: z.string(), topic: z.string(), curriculumId: z.string() }))
      .query(async ({ input }) => {
        const existing = await searchSharedLessons(input.title);
        if (existing.length > 0) {
          await incrementLessonViewCount(existing[0].id);
          return existing[0];
        }
        return null;
      }),

    createLessonWithResources: publicProcedure
      .input(z.object({ cookieId: z.string(), title: z.string(), topic: z.string(), objectives: z.array(z.string()), curriculumId: z.string() }))
      .mutation(async ({ input }) => {
        const lessonPrompt = `Create a comprehensive lesson for: "${input.title}"\nObjectives: ${input.objectives.join(", ")}\n\nProvide detailed, practical content in markdown format with examples.`;
        const content = await callAI(input.cookieId, lessonPrompt, undefined, 3000);
        const resourcesPrompt = `For the topic "${input.topic}", suggest 5 relevant external resources including Wikipedia articles. Return ONLY JSON array: [{"title": "Title", "url": "https://...", "source": "Wikipedia", "description": "Brief"}]`;
        let externalResources: Array<{ title: string; url: string; source: string; description?: string }> = [];
        try {
          const resourcesResponse = await callAI(input.cookieId, resourcesPrompt, undefined, 1024);
          const resourcesMatch = resourcesResponse.match(/\[\s*\{[\s\S]*?\}\s*\]/);
          if (resourcesMatch) {
            externalResources = JSON.parse(resourcesMatch[0]);
          }
        } catch (_e) {
          externalResources = [{ title: `${input.topic} - Wikipedia`, url: `https://en.wikipedia.org/wiki/${input.topic.replace(/\s+/g, '_')}`, source: "Wikipedia", description: "Wikipedia article on the topic" }];
        }
        const lesson: InsertLesson = { cookieId: input.cookieId, curriculumId: input.curriculumId, title: input.title, description: input.objectives.join(", "), content, objectives: input.objectives, keyPoints: input.objectives, resources: [], externalResources, order: 0, difficulty: "intermediate", estimatedMinutes: 30, isShared: true, relatedTopics: [input.topic] };
        const saved = await saveLesson(lesson);
        return saved || { id: 0, ...lesson, completed: false, completedAt: null, createdAt: new Date(), updatedAt: new Date(), viewCount: 0 };
      }),

    rateLessonAndFeedback: publicProcedure.input(z.object({ lessonId: z.number(), cookieId: z.string(), rating: z.number().min(1).max(5), feedback: z.string().optional(), category: z.string().optional() })).mutation(async ({ input }) => { await rateLessonAndFeedback(input.lessonId, input.cookieId, input.rating, input.feedback || "", input.category || "other"); return { success: true }; }),
    getLessonRating: publicProcedure.input(z.object({ lessonId: z.number(), cookieId: z.string() })).query(async ({ input }) => { return await getLessonRating(input.lessonId, input.cookieId); }),
    getLessonStats: publicProcedure.input(z.object({ lessonId: z.number() })).query(async ({ input }) => { return await getLessonStats(input.lessonId); }),
    startLessonProgress: publicProcedure.input(z.object({ cookieId: z.string(), lessonId: z.number() })).mutation(async ({ input }) => { return await startLessonProgress(input.cookieId, input.lessonId); }),
    completeLessonProgress: publicProcedure.input(z.object({ cookieId: z.string(), lessonId: z.number(), timeSpentSeconds: z.number() })).mutation(async ({ input }) => { await completeLessonProgress(input.cookieId, input.lessonId, input.timeSpentSeconds); return { success: true }; }),
    getUserProgress: publicProcedure.input(z.object({ cookieId: z.string() })).query(async ({ input }) => { return await getUserProgress(input.cookieId); }),
    getStudyStats: publicProcedure.input(z.object({ cookieId: z.string() })).query(async ({ input }) => { return await getStudyStats(input.cookieId); }),
    startCurriculumProgress: publicProcedure.input(z.object({ cookieId: z.string(), curriculumId: z.string(), totalLessons: z.number() })).mutation(async ({ input }) => { return await startCurriculumProgress(input.cookieId, input.curriculumId, input.totalLessons); }),
    getCurriculumProgress: publicProcedure.input(z.object({ cookieId: z.string(), curriculumId: z.string() })).query(async ({ input }) => { return await getCurriculumProgress(input.cookieId, input.curriculumId); }),
  }),
});
