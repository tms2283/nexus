import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import PageWrapper from "@/components/PageWrapper";

interface Skill {
  id: string;
  name: string;
  level: number; // 0-100
  category: string;
  color: string;
  x: number;
  y: number;
  related: string[];
  description: string;
  yearsExp: number;
}

const skillData: Skill[] = [
  // Core
  { id: "ts", name: "TypeScript", level: 97, category: "Languages", color: "oklch(0.65 0.22 200)", x: 50, y: 50, related: ["react", "node", "trpc"], description: "Type-safe JavaScript at scale. Primary language for all frontend and Node.js work.", yearsExp: 6 },
  { id: "python", name: "Python", level: 94, category: "Languages", color: "oklch(0.75 0.18 55)", x: 30, y: 35, related: ["fastapi", "ml", "data"], description: "Primary language for AI/ML, data pipelines, and backend services.", yearsExp: 8 },
  { id: "go", name: "Go", level: 78, category: "Languages", color: "oklch(0.65 0.22 200)", x: 70, y: 30, related: ["infra", "grpc"], description: "High-performance services and infrastructure tooling.", yearsExp: 4 },

  // Frontend
  { id: "react", name: "React", level: 98, category: "Frontend", color: "oklch(0.65 0.22 200)", x: 65, y: 55, related: ["ts", "framer", "trpc"], description: "Deep expertise including concurrent features, custom hooks, and performance optimization.", yearsExp: 7 },
  { id: "framer", name: "Framer Motion", level: 90, category: "Frontend", color: "oklch(0.65 0.22 290)", x: 80, y: 50, related: ["react"], description: "Production-grade animations and gesture-driven interfaces.", yearsExp: 4 },
  { id: "threejs", name: "Three.js / WebGL", level: 72, category: "Frontend", color: "oklch(0.65 0.22 290)", x: 85, y: 65, related: ["react"], description: "3D graphics, shader programming, and immersive web experiences.", yearsExp: 3 },
  { id: "tailwind", name: "Tailwind CSS", level: 96, category: "Frontend", color: "oklch(0.65 0.22 200)", x: 55, y: 70, related: ["react"], description: "Utility-first CSS mastery with custom design systems.", yearsExp: 5 },

  // Backend
  { id: "node", name: "Node.js", level: 93, category: "Backend", color: "oklch(0.70 0.20 150)", x: 35, y: 60, related: ["ts", "trpc", "postgres"], description: "High-performance APIs, real-time systems, and microservices.", yearsExp: 7 },
  { id: "fastapi", name: "FastAPI", level: 91, category: "Backend", color: "oklch(0.70 0.20 150)", x: 20, y: 55, related: ["python", "postgres"], description: "Async Python APIs with automatic OpenAPI documentation.", yearsExp: 5 },
  { id: "trpc", name: "tRPC", level: 92, category: "Backend", color: "oklch(0.70 0.20 150)", x: 45, y: 65, related: ["ts", "react", "node"], description: "End-to-end type-safe APIs without code generation.", yearsExp: 3 },
  { id: "grpc", name: "gRPC", level: 80, category: "Backend", color: "oklch(0.70 0.20 150)", x: 75, y: 40, related: ["go", "infra"], description: "High-performance RPC for microservices and streaming.", yearsExp: 4 },

  // Data
  { id: "postgres", name: "PostgreSQL", level: 92, category: "Databases", color: "oklch(0.75 0.18 55)", x: 25, y: 70, related: ["node", "fastapi", "data"], description: "Advanced query optimization, indexing strategies, and schema design.", yearsExp: 7 },
  { id: "redis", name: "Redis", level: 85, category: "Databases", color: "oklch(0.75 0.18 55)", x: 15, y: 45, related: ["node", "infra"], description: "Caching, pub/sub, and distributed data structures.", yearsExp: 6 },
  { id: "data", name: "Data Engineering", level: 82, category: "Databases", color: "oklch(0.75 0.18 55)", x: 15, y: 65, related: ["python", "postgres"], description: "ETL pipelines, data modeling, and analytical systems.", yearsExp: 5 },

  // AI/ML
  { id: "ml", name: "Machine Learning", level: 85, category: "AI & ML", color: "oklch(0.65 0.22 290)", x: 35, y: 20, related: ["python", "llm", "data"], description: "Supervised/unsupervised learning, model training, and deployment.", yearsExp: 5 },
  { id: "llm", name: "LLM Engineering", level: 93, category: "AI & ML", color: "oklch(0.65 0.22 290)", x: 50, y: 20, related: ["python", "ml", "rag"], description: "Prompt engineering, fine-tuning, RAG systems, and multi-model orchestration.", yearsExp: 3 },
  { id: "rag", name: "RAG Systems", level: 90, category: "AI & ML", color: "oklch(0.65 0.22 290)", x: 65, y: 20, related: ["llm", "postgres"], description: "Retrieval-augmented generation with vector databases and semantic search.", yearsExp: 2 },

  // Infra
  { id: "infra", name: "Kubernetes", level: 78, category: "Infrastructure", color: "oklch(0.65 0.22 200)", x: 80, y: 30, related: ["go", "grpc"], description: "Container orchestration, service mesh, and cloud-native architecture.", yearsExp: 4 },
  { id: "aws", name: "AWS", level: 83, category: "Infrastructure", color: "oklch(0.65 0.22 200)", x: 90, y: 45, related: ["infra", "node"], description: "EC2, Lambda, RDS, S3, CloudFront, and serverless architectures.", yearsExp: 6 },

  // Design
  { id: "design", name: "System Design", level: 90, category: "Architecture", color: "oklch(0.75 0.18 55)", x: 50, y: 82, related: ["node", "infra", "postgres"], description: "Distributed systems, scalability patterns, and architectural decision-making.", yearsExp: 6 },
];

const categoryColors: Record<string, string> = {
  "Languages": "oklch(0.75 0.18 55)",
  "Frontend": "oklch(0.65 0.22 200)",
  "Backend": "oklch(0.70 0.20 150)",
  "Databases": "oklch(0.75 0.18 55)",
  "AI & ML": "oklch(0.65 0.22 290)",
  "Infrastructure": "oklch(0.65 0.22 200)",
  "Architecture": "oklch(0.75 0.18 55)",
};

export default function Skills() {
  const [selected, setSelected] = useState<Skill | null>(null);
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const [dims, setDims] = useState({ w: 800, h: 600 });

  useEffect(() => {
    const update = () => {
      if (svgRef.current) {
        const rect = svgRef.current.getBoundingClientRect();
        setDims({ w: rect.width, h: rect.height });
      }
    };
    update();
    window.addEventListener("resize", update);
    return () => window.removeEventListener("resize", update);
  }, []);

  const categories = Array.from(new Set(skillData.map(s => s.category)));

  const visibleSkills = activeCategory
    ? skillData.filter(s => s.category === activeCategory || skillData.find(ss => ss.id === s.id && ss.related.some(r => skillData.find(x => x.id === r && x.category === activeCategory))))
    : skillData;

  const getPos = (skill: Skill) => ({
    x: (skill.x / 100) * dims.w,
    y: (skill.y / 100) * dims.h,
  });

  const isHighlighted = (skill: Skill) => {
    if (!hoveredId && !selected) return true;
    const activeId = hoveredId || selected?.id;
    if (!activeId) return true;
    const active = skillData.find(s => s.id === activeId);
    if (!active) return true;
    return skill.id === activeId || active.related.includes(skill.id) || skill.related.includes(activeId);
  };

  return (
    <PageWrapper pageName="skills">
      {/* Header */}
      <section className="py-24 border-b border-white/5">
        <div className="container">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-3 mb-8">
            <div className="h-px w-12 bg-gradient-to-r from-transparent to-[oklch(0.75_0.18_55)]" />
            <span className="text-[oklch(0.75_0.18_55)] text-sm font-medium tracking-widest uppercase">Skills</span>
          </motion.div>
          <motion.h1 initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="text-5xl md:text-7xl font-bold tracking-tight mb-6">
            Mastery <span className="text-gradient-gold">Map.</span>
          </motion.h1>
          <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="text-lg text-muted-foreground max-w-2xl">
            An interactive graph of technical expertise. Hover to explore connections. Click for details.
          </motion.p>
        </div>
      </section>

      {/* Category filter */}
      <section className="py-6 border-b border-white/5">
        <div className="container flex gap-2 overflow-x-auto pb-1">
          <button onClick={() => setActiveCategory(null)} className={`shrink-0 px-4 py-2 rounded-xl text-sm font-medium transition-all ${!activeCategory ? "bg-[oklch(0.75_0.18_55_/_0.15)] text-[oklch(0.85_0.18_55)] border border-[oklch(0.75_0.18_55_/_0.4)]" : "glass border border-white/10 text-muted-foreground hover:text-foreground"}`}>
            All
          </button>
          {categories.map(cat => (
            <button key={cat} onClick={() => setActiveCategory(cat === activeCategory ? null : cat)} className={`shrink-0 px-4 py-2 rounded-xl text-sm font-medium transition-all ${activeCategory === cat ? "border" : "glass border border-white/10 text-muted-foreground hover:text-foreground"}`}
              style={activeCategory === cat ? { background: `${categoryColors[cat].replace(")", " / 0.15)")}`, borderColor: categoryColors[cat].replace(")", " / 0.4)"), color: categoryColors[cat] } : {}}>
              {cat}
            </button>
          ))}
        </div>
      </section>

      {/* Graph */}
      <section className="py-8">
        <div className="container">
          <div className="relative glass rounded-3xl border border-white/10 overflow-hidden" style={{ height: "600px" }}>
            <svg ref={svgRef} className="absolute inset-0 w-full h-full">
              {/* Connection lines */}
              {skillData.map(skill =>
                skill.related.map(relId => {
                  const rel = skillData.find(s => s.id === relId);
                  if (!rel || skill.id > relId) return null;
                  const p1 = getPos(skill);
                  const p2 = getPos(rel);
                  const highlighted = isHighlighted(skill) && isHighlighted(rel);
                  return (
                    <line key={`${skill.id}-${relId}`}
                      x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y}
                      stroke={highlighted ? skill.color.replace(")", " / 0.25)") : "oklch(0.5 0.02 260 / 0.08)"}
                      strokeWidth={highlighted ? 1.5 : 0.5}
                      className="transition-all duration-300"
                    />
                  );
                })
              )}

              {/* Nodes */}
              {skillData.map(skill => {
                const pos = getPos(skill);
                const highlighted = isHighlighted(skill);
                const isSelected = selected?.id === skill.id;
                const size = 8 + (skill.level / 100) * 14;

                return (
                  <g key={skill.id}
                    transform={`translate(${pos.x}, ${pos.y})`}
                    className="cursor-pointer"
                    onMouseEnter={() => setHoveredId(skill.id)}
                    onMouseLeave={() => setHoveredId(null)}
                    onClick={() => setSelected(selected?.id === skill.id ? null : skill)}
                  >
                    {/* Glow */}
                    {(highlighted || isSelected) && (
                      <circle r={size + 8} fill={skill.color.replace(")", " / 0.08)")} className="transition-all duration-300" />
                    )}
                    {/* Node */}
                    <circle
                      r={size}
                      fill={highlighted ? skill.color.replace(")", " / 0.25)") : "oklch(0.3 0.02 260 / 0.3)"}
                      stroke={highlighted ? skill.color.replace(")", " / 0.7)") : "oklch(0.4 0.02 260 / 0.2)"}
                      strokeWidth={isSelected ? 2.5 : 1.5}
                      className="transition-all duration-300"
                    />
                    {/* Label */}
                    {(highlighted || hoveredId === skill.id) && (
                      <text
                        y={size + 14}
                        textAnchor="middle"
                        fontSize={10}
                        fill={highlighted ? "oklch(0.85 0.05 260)" : "oklch(0.5 0.02 260)"}
                        className="pointer-events-none select-none transition-all duration-300"
                        fontWeight={isSelected ? "700" : "500"}
                      >
                        {skill.name}
                      </text>
                    )}
                  </g>
                );
              })}
            </svg>

            {/* Legend */}
            <div className="absolute top-4 right-4 glass rounded-xl p-3 border border-white/10">
              <div className="text-xs text-muted-foreground mb-2 font-medium">Node size = proficiency</div>
              {Object.entries(categoryColors).slice(0, 4).map(([cat, color]) => (
                <div key={cat} className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
                  <div className="w-2 h-2 rounded-full" style={{ background: color }} />
                  {cat}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Selected skill detail */}
      <AnimatePresence>
        {selected && (
          <motion.section
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="py-8"
          >
            <div className="container">
              <div className="glass rounded-2xl border p-6 max-w-2xl" style={{ borderColor: selected.color.replace(")", " / 0.3)") }}>
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <div className="text-xs font-medium mb-1" style={{ color: selected.color }}>{selected.category}</div>
                    <h3 className="text-2xl font-bold text-foreground">{selected.name}</h3>
                  </div>
                  <div className="text-right">
                    <div className="text-3xl font-bold" style={{ color: selected.color }}>{selected.level}%</div>
                    <div className="text-xs text-muted-foreground">{selected.yearsExp}yr exp</div>
                  </div>
                </div>
                <p className="text-muted-foreground text-sm leading-relaxed mb-4">{selected.description}</p>
                <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
                  <motion.div
                    className="h-full rounded-full"
                    style={{ background: `linear-gradient(90deg, ${selected.color}, ${selected.color.replace(")", " / 0.5)")})` }}
                    initial={{ width: 0 }}
                    animate={{ width: `${selected.level}%` }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                  />
                </div>
                <div className="mt-4 flex flex-wrap gap-2">
                  {selected.related.map(relId => {
                    const rel = skillData.find(s => s.id === relId);
                    if (!rel) return null;
                    return (
                      <button key={relId} onClick={() => setSelected(rel)} className="px-3 py-1 rounded-lg text-xs glass border border-white/10 text-muted-foreground hover:text-foreground transition-colors">
                        {rel.name}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </motion.section>
        )}
      </AnimatePresence>

      {/* Skill bars grid */}
      <section className="py-16 border-t border-white/5">
        <div className="container">
          <h2 className="text-2xl font-bold mb-8">Proficiency Overview</h2>
          <div className="grid md:grid-cols-2 gap-4">
            {skillData.sort((a, b) => b.level - a.level).map((skill, i) => (
              <motion.div
                key={skill.id}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.03 }}
                className="flex items-center gap-4 p-4 glass rounded-xl border border-white/10 cursor-pointer hover:border-white/20 transition-all"
                onClick={() => setSelected(skill)}
              >
                <div className="w-32 shrink-0">
                  <div className="text-sm font-medium text-foreground">{skill.name}</div>
                  <div className="text-xs text-muted-foreground">{skill.category}</div>
                </div>
                <div className="flex-1 h-1.5 bg-white/10 rounded-full overflow-hidden">
                  <motion.div
                    className="h-full rounded-full"
                    style={{ background: skill.color }}
                    initial={{ width: 0 }}
                    whileInView={{ width: `${skill.level}%` }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.8, ease: "easeOut", delay: i * 0.02 }}
                  />
                </div>
                <span className="text-sm font-mono text-muted-foreground w-10 text-right">{skill.level}%</span>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </PageWrapper>
  );
}
